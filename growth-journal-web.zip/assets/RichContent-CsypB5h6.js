import{j as e}from"./index-C1ZxpkkS.js";function o({html:t,className:n=""}){return e.jsx("div",{className:`rich-content ${n}`,dangerouslySetInnerHTML:{__html:t}})}export{o as R};
