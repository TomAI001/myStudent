import{c as w,r as c,j as e,f as $,u as oe}from"./index-C1ZxpkkS.js";import{C as T}from"./code-xml-CjnRztAq.js";import{R as D,d as ce,c as Y,S as de,C as R,b as X,I as J,P as he,E as ue,e as xe,U as me,f as pe,L as je,a as fe}from"./users-round-CxiezQEe.js";import{P as O}from"./play-WIe6OJ9H.js";import{g as ye,a as V,b as ge,s as be,c as ve,d as A,e as I,f as ke}from"./studentPortal-7KsqJhSQ.js";import{g as C,a as _e,c as B,s as H,U as we,b as Ne}from"./studentLearningStore-Cfjf_W0c.js";import{C as ee}from"./chevron-right-Cvf7ktav.js";import{A as F}from"./arrow-left-DrkNWsTs.js";import{S as se}from"./sparkles-DVOROvIS.js";import{C as Se}from"./calendar-days-Dzb6hVBL.js";import{G as te}from"./gamepad-2-DUkrghA1.js";import{B as ne}from"./book-open-FvInB1iW.js";import{L as le}from"./lock-keyhole-opfxxH_V.js";import{K as Ce}from"./key-round-CcKZzajN.js";const Me=w("AlarmClock",[["circle",{cx:"12",cy:"13",r:"8",key:"3y4lt7"}],["path",{d:"M12 9v4l2 2",key:"1c63tq"}],["path",{d:"M5 3 2 6",key:"18tl5t"}],["path",{d:"m22 6-3-3",key:"1opdir"}],["path",{d:"M6.38 18.7 4 21",key:"17xu3x"}],["path",{d:"M17.64 18.67 20 21",key:"kv2oe2"}]]);const Le=w("CalendarClock",[["path",{d:"M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.5",key:"1osxxc"}],["path",{d:"M16 2v4",key:"4m81vk"}],["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M3 10h5",key:"r794hk"}],["path",{d:"M17.5 17.5 16 16.3V14",key:"akvzfd"}],["circle",{cx:"16",cy:"16",r:"6",key:"qoo3c4"}]]);const Pe=w("CircleX",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m15 9-6 6",key:"1uzhvr"}],["path",{d:"m9 9 6 6",key:"z0biqf"}]]);const Ee=w("Clock3",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16.5 12",key:"1aq6pp"}]]);const Ie=w("Crown",[["path",{d:"M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z",key:"1vdc57"}],["path",{d:"M5 21h14",key:"11awu3"}]]);const Te=w("FileImage",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["circle",{cx:"10",cy:"12",r:"2",key:"737tya"}],["path",{d:"m20 17-1.296-1.296a2.41 2.41 0 0 0-3.408 0L9 22",key:"wt3hpn"}]]);const Ae=w("FileQuestion",[["path",{d:"M12 17h.01",key:"p32p05"}],["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z",key:"1mlx9k"}],["path",{d:"M9.1 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3",key:"mhlwft"}]]);const Re=w("FileVideo",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"m10 11 5 3-5 3v-6Z",key:"7ntvm4"}]]);const ze=w("Heart",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}]]);const Oe=w("ImageUp",[["path",{d:"M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21",key:"9csbqa"}],["path",{d:"m14 19.5 3-3 3 3",key:"9vmjn0"}],["path",{d:"M17 22v-5.5",key:"1aa6fl"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}]]);const qe=w("Maximize2",[["polyline",{points:"15 3 21 3 21 9",key:"mznyad"}],["polyline",{points:"9 21 3 21 3 15",key:"1avn1i"}],["line",{x1:"21",x2:"14",y1:"3",y2:"10",key:"ota7mn"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]]);const Ve=w("Medal",[["path",{d:"M7.21 15 2.66 7.14a2 2 0 0 1 .13-2.2L4.4 2.8A2 2 0 0 1 6 2h12a2 2 0 0 1 1.6.8l1.6 2.14a2 2 0 0 1 .14 2.2L16.79 15",key:"143lza"}],["path",{d:"M11 12 5.12 2.2",key:"qhuxz6"}],["path",{d:"m13 12 5.88-9.8",key:"hbye0f"}],["path",{d:"M8 7h8",key:"i86dvs"}],["circle",{cx:"12",cy:"17",r:"5",key:"qbz8iq"}],["path",{d:"M12 18v-2h-.5",key:"fawc4q"}]]);const Ue=w("MessageCircleMore",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}],["path",{d:"M8 12h.01",key:"czm47f"}],["path",{d:"M12 12h.01",key:"1mp3jc"}],["path",{d:"M16 12h.01",key:"1l6xoz"}]]);const Q=w("MessageCircle",[["path",{d:"M7.9 20A9 9 0 1 0 4 16.1L2 22Z",key:"vv11sd"}]]);const $e=w("Minimize2",[["polyline",{points:"4 14 10 14 10 20",key:"11kfnr"}],["polyline",{points:"20 10 14 10 14 4",key:"rlmsce"}],["line",{x1:"14",x2:"21",y1:"10",y2:"3",key:"o5lafz"}],["line",{x1:"3",x2:"10",y1:"21",y2:"14",key:"1atl0r"}]]);const q=w("Send",[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]]);const De=w("SquareTerminal",[["path",{d:"m7 11 2-2-2-2",key:"1lz0vl"}],["path",{d:"M11 13h4",key:"1p7l4v"}],["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}]]);const ae=w("Star",[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]]);const Be=w("Timer",[["line",{x1:"10",x2:"14",y1:"2",y2:"2",key:"14vaq8"}],["line",{x1:"12",x2:"15",y1:"14",y2:"11",key:"17fdiu"}],["circle",{cx:"12",cy:"14",r:"8",key:"1e1u0o"}]]);const re=w("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]]);const He=w("Video",[["path",{d:"m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",key:"ftymec"}],["rect",{x:"2",y:"6",width:"14",height:"12",rx:"2",key:"158x01"}]]);const Fe=w("Zap",[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]]);let z=null;const G="https://cdn.jsdelivr.net/pyodide/v0.28.2/full/",Ze=String.raw`
import math as _math
import sys as _sys
import types as _types
from js import document as _document

_canvas = _document.getElementById("student-turtle-canvas")
if _canvas is None:
    raise RuntimeError("找不到海龟绘图画布")

_canvas.width = 720
_canvas.height = 420
_ctx = _canvas.getContext("2d")
_ctx.clearRect(0, 0, _canvas.width, _canvas.height)
_ctx.fillStyle = "#ffffff"
_ctx.fillRect(0, 0, _canvas.width, _canvas.height)
_ctx.lineCap = "round"
_ctx.lineJoin = "round"

def _point(x, y):
    return (_canvas.width / 2 + x, _canvas.height / 2 - y)

class _Turtle:
    def __init__(self, shape="classic", visible=True):
        self._x = 0.0
        self._y = 0.0
        self._heading = 0.0
        self._down = True
        self._color = "#162236"
        self._fillcolor = "#7be99b"
        self._width = 2
        self._visible = visible

    def _move_to(self, nx, ny):
        if self._down:
            x1, y1 = _point(self._x, self._y)
            x2, y2 = _point(nx, ny)
            _ctx.beginPath()
            _ctx.moveTo(x1, y1)
            _ctx.lineTo(x2, y2)
            _ctx.strokeStyle = self._color
            _ctx.lineWidth = self._width
            _ctx.stroke()
        self._x, self._y = float(nx), float(ny)

    def forward(self, distance):
        angle = _math.radians(self._heading)
        self._move_to(self._x + _math.cos(angle) * distance,
                      self._y + _math.sin(angle) * distance)

    fd = forward

    def backward(self, distance):
        self.forward(-distance)

    back = backward
    bk = backward

    def right(self, angle):
        self._heading = (self._heading - angle) % 360

    rt = right

    def left(self, angle):
        self._heading = (self._heading + angle) % 360

    lt = left

    def goto(self, x, y=None):
        if y is None:
            x, y = x
        self._move_to(float(x), float(y))

    setpos = goto
    setposition = goto

    def setx(self, x): self._move_to(float(x), self._y)
    def sety(self, y): self._move_to(self._x, float(y))
    def setheading(self, angle): self._heading = float(angle) % 360
    seth = setheading
    def heading(self): return self._heading
    def position(self): return (self._x, self._y)
    pos = position
    def xcor(self): return self._x
    def ycor(self): return self._y

    def penup(self): self._down = False
    pu = penup
    up = penup
    def pendown(self): self._down = True
    pd = pendown
    down = pendown
    def isdown(self): return self._down

    def pensize(self, width=None):
        if width is None: return self._width
        self._width = float(width)
    width = pensize

    def pencolor(self, color=None):
        if color is None: return self._color
        self._color = str(color)

    def fillcolor(self, color=None):
        if color is None: return self._fillcolor
        self._fillcolor = str(color)

    def color(self, *colors):
        if not colors: return (self._color, self._fillcolor)
        self._color = str(colors[0])
        self._fillcolor = str(colors[-1])

    def circle(self, radius, extent=360, steps=None):
        extent = 360 if extent is None else float(extent)
        steps = int(steps or max(12, abs(extent) // 6))
        if steps <= 0: return
        step_angle = extent / steps
        step_length = 2 * _math.pi * abs(radius) * abs(extent) / 360 / steps
        turn = step_angle if radius >= 0 else -step_angle
        for _ in range(steps):
            self.left(turn / 2)
            self.forward(step_length if radius >= 0 else -step_length)
            self.left(turn / 2)

    def dot(self, size=6, color=None):
        x, y = _point(self._x, self._y)
        _ctx.beginPath()
        _ctx.arc(x, y, float(size) / 2, 0, 2 * _math.pi)
        _ctx.fillStyle = str(color or self._color)
        _ctx.fill()

    def write(self, text, move=False, align="left", font=("Arial", 14, "normal")):
        x, y = _point(self._x, self._y)
        size = font[1] if len(font) > 1 else 14
        family = font[0] if font else "Arial"
        _ctx.fillStyle = self._color
        _ctx.font = f"{size}px {family}"
        _ctx.textAlign = align
        _ctx.fillText(str(text), x, y)

    def home(self):
        self.goto(0, 0)
        self.setheading(0)

    def clear(self):
        _ctx.clearRect(0, 0, _canvas.width, _canvas.height)
        _ctx.fillStyle = "#ffffff"
        _ctx.fillRect(0, 0, _canvas.width, _canvas.height)

    def reset(self):
        self.clear()
        self._x = self._y = self._heading = 0.0
        self._down = True

    def speed(self, value=None): return 0
    def hideturtle(self): self._visible = False
    ht = hideturtle
    def showturtle(self): self._visible = True
    st = showturtle
    def begin_fill(self): pass
    def end_fill(self): pass
    def shape(self, value=None): return "classic"

class _Screen:
    def bgcolor(self, color=None):
        if color is None: return "white"
        _ctx.fillStyle = str(color)
        _ctx.fillRect(0, 0, _canvas.width, _canvas.height)
    def title(self, value): return value
    def setup(self, width=None, height=None, startx=None, starty=None): return None
    def tracer(self, *args): return None
    def update(self): return None
    def exitonclick(self): return None
    def mainloop(self): return None
    def bye(self): return None

_default_turtle = _Turtle()
_screen = _Screen()
_module = _types.ModuleType("turtle")
_module.Turtle = _Turtle
_module.RawTurtle = _Turtle
_module.Pen = _Turtle
_module.Screen = lambda: _screen
_module.TurtleScreen = _Screen

for _name in (
    "forward", "fd", "backward", "back", "bk", "right", "rt", "left", "lt",
    "goto", "setpos", "setposition", "setx", "sety", "setheading", "seth",
    "heading", "position", "pos", "xcor", "ycor", "penup", "pu", "up",
    "pendown", "pd", "down", "isdown", "pensize", "width", "pencolor",
    "fillcolor", "color", "circle", "dot", "write", "home", "clear", "reset",
    "speed", "hideturtle", "ht", "showturtle", "st", "begin_fill", "end_fill", "shape"
):
    setattr(_module, _name, getattr(_default_turtle, _name))

_module.done = lambda: None
_module.mainloop = lambda: None
_module.exitonclick = lambda: None
_module.bgcolor = _screen.bgcolor
_module.title = _screen.title
_module.setup = _screen.setup
_module.tracer = _screen.tracer
_module.update = _screen.update
_module.__all__ = [name for name in dir(_module) if not name.startswith("_")]
_sys.modules["turtle"] = _module
`;function Ke(){return z||(z=new Promise((l,i)=>{const d=()=>window.loadPyodide?.({indexURL:G}).then(l).catch(i);if(window.loadPyodide)return d();const n=document.createElement("script");n.src=`${G}pyodide.js`,n.async=!0,n.onload=d,n.onerror=()=>i(new Error("Python 运行组件加载失败")),document.head.appendChild(n)}),z)}function U(l){return/(^|\n)\s*(?:import\s+turtle\b|from\s+turtle\s+import\b)/m.test(l)}async function Z(l,i){const d=await Ke(),n=[],r=x=>{n.push(x),i?.(n.join(`
`))};return d.setStdout({batched:r}),d.setStderr({batched:r}),U(l)&&await d.runPythonAsync(Ze),await d.runPythonAsync(l),n.join(`
`)||(U(l)?"海龟绘图运行完成，请查看上方画布。":"程序运行完成（没有输出内容）。")}const W=`# 我的 Python 小程序
name = "林小满"
for level in range(1, 4):
    print(f"{name} 解锁了第 {level} 关！")
print("编程冒险继续出发！")`;function Qe(){const[l,i]=c.useState(()=>window.localStorage.getItem("growth-python-draft")||W),[d,n]=c.useState("点击“运行程序”，这里会显示结果。"),[r,x]=c.useState(!1),[p,k]=c.useState(!1),y=U(l);c.useEffect(()=>{if(!p)return;const h=window.setTimeout(()=>k(!1),1600);return()=>window.clearTimeout(h)},[p]);const o=async()=>{x(!0),n("正在启动 Python…第一次运行需要下载运行组件。");try{n(await Z(l,n))}catch(h){n(`运行出错：
${h instanceof Error?h.message:String(h)}`)}finally{x(!1)}},s=()=>{window.localStorage.setItem("growth-python-draft",l),k(!0)};return e.jsxs("section",{className:"python-lab",children:[e.jsxs("div",{className:"lab-heading",children:[e.jsxs("div",{children:[e.jsx("span",{children:e.jsx(T,{})}),e.jsxs("div",{children:[e.jsx("small",{children:"PYTHON PLAYGROUND"}),e.jsx("h2",{children:"代码实验室"})]})]}),e.jsx("p",{children:"支持基础 Python 与 Turtle 海龟绘图；tkinter、Pygame 将由服务器图形环境运行。"})]}),e.jsxs("div",{className:"lab-window",children:[e.jsxs("div",{className:"lab-toolbar",children:[e.jsxs("span",{className:"window-dots",children:[e.jsx("i",{}),e.jsx("i",{}),e.jsx("i",{})]}),e.jsx("strong",{children:"main.py"}),e.jsxs("div",{children:[e.jsxs("button",{type:"button",onClick:()=>i(W),children:[e.jsx(D,{})," 重置"]}),e.jsxs("button",{type:"button",onClick:s,children:[e.jsx(ce,{})," ",p?"已保存":"保存代码"]}),e.jsxs("button",{type:"button",className:"run-code",onClick:o,disabled:r,children:[r?e.jsx($,{className:"spin"}):e.jsx(O,{})," ",r?"运行中":"运行程序"]})]})]}),e.jsxs("div",{className:"lab-grid",children:[e.jsxs("div",{className:"code-editor-wrap",children:[e.jsx("div",{className:"line-numbers",children:l.split(`
`).map((h,b)=>e.jsx("span",{children:b+1},b))}),e.jsx("textarea",{value:l,onChange:h=>i(h.target.value),spellCheck:!1,"aria-label":"Python 代码编辑器"})]}),e.jsxs("div",{className:`console-panel ${y?"has-turtle-canvas":""}`,children:[e.jsxs("div",{children:[e.jsx(De,{})," ",y?"海龟绘图结果":"运行结果"]}),y&&e.jsx("div",{className:"turtle-canvas-wrap",children:e.jsx("canvas",{id:"student-turtle-canvas",width:"720",height:"420","aria-label":"Turtle 海龟绘图画布"})}),e.jsx("pre",{children:d})]})]})]})]})}function Ge({studentId:l,onBack:i}){const[d,n]=c.useState(C),[r,x]=c.useState(null),[p,k]=c.useState({}),[y,o]=c.useState(null),[s,h]=c.useState(null),b=d.assessments.filter(m=>m.published),S=m=>{x(m),k({}),o(null),h(Date.now())},_=()=>{if(!r||!window.confirm("确认提交这份测评吗？提交后会立即显示客观题结果。"))return;const m=_e(r,l,p);o(m),n(C())},u=m=>d.assessmentSubmissions.filter(a=>a.assessmentId===m&&a.studentId===l);return r?e.jsx(We,{assessment:r,answers:p,setAnswers:k,result:y,startedAt:s,onSubmit:_,onExit:()=>x(null)}):e.jsxs("main",{className:"student-module-page",children:[e.jsx(K,{icon:Y,label:"ASSESSMENT CENTER",title:"测评挑战",description:"认真作答，客观题提交后立即显示结果。",onBack:i}),e.jsx("section",{className:"assessment-grid",children:b.map(m=>{const a=u(m.id),v=a.length>=m.maxAttempts;return e.jsxs("article",{className:"assessment-card",children:[e.jsxs("div",{className:"assessment-card-top",children:[e.jsx("span",{className:m.kind,children:e.jsx(Ae,{})}),e.jsxs("div",{children:[e.jsx("small",{children:m.kind==="course"?"课程测评":"心理测评"}),e.jsx("h2",{children:m.title})]})]}),e.jsx("p",{children:m.description}),e.jsxs("div",{className:"assessment-meta",children:[e.jsxs("span",{children:[e.jsx(Be,{})," ",m.durationMinutes," 分钟"]}),e.jsxs("span",{children:[e.jsx(D,{})," ",a.length,"/",m.maxAttempts," 次"]}),e.jsxs("span",{children:[e.jsx(de,{})," 自动保存"]})]}),e.jsxs("button",{type:"button",disabled:v,onClick:()=>S(m),children:[v?"作答次数已用完":a.length?"再次挑战":"开始测评"," ",e.jsx(ee,{})]}),a[0]&&e.jsxs("div",{className:"last-score",children:[e.jsx("span",{children:"上次客观题"}),e.jsxs("strong",{children:[a.at(-1)?.autoScore," 分"]})]})]},m.id)})})]})}function We({assessment:l,answers:i,setAnswers:d,result:n,startedAt:r,onSubmit:x,onExit:p}){const k=l.questions.reduce((s,h)=>s+h.points,0),y=Object.values(i).filter(Boolean).length,o=r?Math.max(1,Math.round((Date.now()-r)/6e4)):0;return e.jsxs("main",{className:"student-module-page",children:[e.jsxs("div",{className:"paper-topbar",children:[e.jsxs("button",{type:"button",onClick:p,children:[e.jsx(F,{})," 返回测评列表"]}),e.jsxs("div",{children:[e.jsx("small",{children:"ASSESSMENT IN PROGRESS"}),e.jsx("strong",{children:l.title})]}),e.jsxs("span",{children:[e.jsx(Me,{})," ",n?`用时 ${o} 分钟`:`${l.durationMinutes} 分钟`]})]}),n&&e.jsxs("section",{className:"result-banner",children:[e.jsx("span",{children:e.jsx(R,{})}),e.jsxs("div",{children:[e.jsx("small",{children:"客观题成绩已公布"}),e.jsxs("h1",{children:[n.autoScore,e.jsxs("em",{children:[" / ",k," 分"]})]}),e.jsx("p",{children:n.manualPending?"编程题正在等待老师评分，完成后总成绩会更新。":"本次测评已完成。"})]})]}),e.jsx("section",{className:"assessment-paper",children:l.questions.map((s,h)=>{const b=i[s.id]||"",S=n&&s.type!=="programming"&&b.trim().toLowerCase()===s.answer?.trim().toLowerCase();return e.jsxs("article",{className:`question-block ${n?S?"answer-correct":s.type==="programming"?"answer-manual":"answer-wrong":""}`,children:[e.jsxs("header",{children:[e.jsx("span",{children:String(h+1).padStart(2,"0")}),e.jsxs("div",{children:[e.jsxs("small",{children:[s.type==="choice"?"选择题":s.type==="true_false"?"判断题":s.type==="blank"?"程序填空题":"编程题"," · ",s.points," 分"]}),e.jsx("h2",{children:s.title})]}),n&&(s.type==="programming"?e.jsx(T,{}):S?e.jsx(R,{}):e.jsx(Pe,{}))]}),(s.type==="choice"||s.type==="true_false")&&e.jsx("div",{className:"question-options",children:s.options?.map(_=>e.jsxs("button",{type:"button",disabled:!!n,className:b===_?"selected":"",onClick:()=>d(u=>({...u,[s.id]:_})),children:[e.jsx("i",{children:String.fromCharCode(65+(s.options?.indexOf(_)||0))}),_]},_))}),s.type==="blank"&&e.jsx("input",{disabled:!!n,value:b,onChange:_=>d(u=>({...u,[s.id]:_.target.value})),placeholder:"在这里填写缺少的代码"}),s.type==="programming"&&e.jsx("textarea",{disabled:!!n,value:b,onChange:_=>d(u=>({...u,[s.id]:_.target.value})),rows:8,spellCheck:!1,placeholder:"# 在这里编写 Python 程序"}),n&&s.type!=="programming"&&e.jsxs("p",{className:"answer-explain",children:["正确答案：",e.jsx("strong",{children:s.answer})]}),n&&s.type==="programming"&&e.jsx("p",{className:"answer-explain",children:"已提交，等待老师人工评分。"})]},s.id)})}),!n&&e.jsxs("div",{className:"paper-submit",children:[e.jsxs("span",{children:["已完成 ",y,"/",l.questions.length," 题"]}),e.jsxs("button",{type:"button",onClick:x,children:[e.jsx(q,{})," 提交测评"]})]})]})}function K({icon:l,label:i,title:d,description:n,onBack:r}){return e.jsxs("div",{className:"student-module-heading",children:[e.jsxs("button",{type:"button",onClick:r,children:[e.jsx(F,{})," 返回冒险大厅"]}),e.jsx("div",{className:"module-heading-icon",children:e.jsx(l,{})}),e.jsxs("div",{children:[e.jsx("span",{children:i}),e.jsx("h1",{children:d}),e.jsx("p",{children:n})]})]})}function Ye({studentId:l,studentName:i,onBack:d}){const[n,r]=c.useState(C),[x,p]=c.useState(null),k=n.homework.filter(o=>o.published),y=o=>n.homeworkSubmissions.filter(s=>s.homeworkId===o&&s.studentId===l);return x?e.jsx(Xe,{assignment:x,studentId:l,studentName:i,previous:y(x.id),onBack:()=>{r(C()),p(null)}}):e.jsxs("main",{className:"student-module-page",children:[e.jsx(K,{icon:X,label:"HOMEWORK STATION",title:"上传作业",description:"可以在线编写代码，也可以提交照片或演示视频。",onBack:d}),e.jsx("section",{className:"homework-student-grid",children:k.map(o=>{const s=y(o.id),h=s.at(-1);return e.jsxs("article",{className:"homework-student-card",children:[e.jsx("div",{className:"homework-status-icon",children:e.jsx(T,{})}),e.jsxs("div",{className:"homework-main",children:[e.jsx("span",{className:"homework-label",children:"PYTHON HOMEWORK"}),e.jsx("h2",{children:o.title}),e.jsx("p",{children:o.description}),e.jsxs("div",{children:[e.jsxs("span",{children:[e.jsx(Le,{})," 截止 ",Je(o.dueAt)]}),e.jsxs("span",{children:[e.jsx(D,{})," 可提交 ",o.maxSubmissions," 次"]})]})]}),e.jsxs("aside",{children:[h?e.jsxs(e.Fragment,{children:[e.jsxs("span",{className:"submitted-mark",children:[e.jsx(R,{})," 已提交 ",s.length," 次"]}),h.score!==null?e.jsxs("strong",{children:[h.score," 分"]}):e.jsx("em",{children:"等待老师评分"})]}):e.jsxs("span",{className:"todo-mark",children:[e.jsx(Ee,{})," 待完成"]}),e.jsx("button",{type:"button",disabled:s.length>=o.maxSubmissions,onClick:()=>p(o),children:s.length?"修改并重交":"开始作业"})]}),h?.feedback&&e.jsxs("div",{className:"teacher-feedback",children:[e.jsx("strong",{children:"老师评语"}),e.jsx("p",{children:h.feedback})]})]},o.id)})})]})}function Xe({assignment:l,studentId:i,studentName:d,previous:n,onBack:r}){const x=n.at(-1),[p,k]=c.useState(x?.code||`# 在这里完成作业
score = 85
if score >= 60:
    print("挑战成功！")`),[y,o]=c.useState(x?.note||""),[s,h]=c.useState([]),[b,S]=c.useState(null),[_,u]=c.useState("运行代码后，这里会显示结果。"),[m,a]=c.useState(!1),[v,P]=c.useState(!1),E=c.useMemo(()=>s.map(j=>URL.createObjectURL(j)),[s]),t=j=>{if(!j)return;const M=[...s,...Array.from(j).filter(L=>L.type.startsWith("image/"))].slice(0,10);h(M)},f=async j=>{if(!j)return;if(j.size>200*1024*1024)return window.alert("单个视频不能超过 200MB。");const M=URL.createObjectURL(j),L=document.createElement("video");L.preload="metadata",L.src=M,L.onloadedmetadata=()=>{URL.revokeObjectURL(M),L.duration>300?window.alert("视频最长不能超过 5 分钟。"):S(j)},L.onerror=()=>{URL.revokeObjectURL(M),window.alert("无法读取视频，请换一个文件。")}},g=async()=>{a(!0),u("正在启动 Python…");try{u(await Z(p,u))}catch(j){u(`运行出错：
${j instanceof Error?j.message:String(j)}`)}finally{a(!1)}},N=()=>{const j=C();j.homeworkSubmissions.push({id:B("homework-submit"),homeworkId:l.id,studentId:i,studentName:d,code:p,note:y,photos:s.map(M=>M.name),video:b?.name||null,submittedAt:new Date().toISOString(),attempt:n.length+1,score:null,feedback:""}),H(j),P(!0)};return v?e.jsx("main",{className:"student-module-page",children:e.jsxs("section",{className:"submission-success",children:[e.jsx("span",{children:e.jsx(R,{})}),e.jsx("h1",{children:"作业提交成功！"}),e.jsx("p",{children:"老师评分后，你可以在作业列表查看分数和评语。"}),e.jsx("button",{type:"button",onClick:r,children:"返回作业列表"})]})}):e.jsxs("main",{className:"student-module-page",children:[e.jsxs("div",{className:"homework-editor-heading",children:[e.jsx("button",{type:"button",onClick:r,children:"← 返回作业列表"}),e.jsxs("span",{children:["第 ",n.length+1," 次提交"]}),e.jsx("h1",{children:l.title}),e.jsx("p",{children:l.description})]}),e.jsxs("div",{className:"homework-editor-grid",children:[e.jsxs("section",{className:"homework-code-card",children:[e.jsxs("header",{children:[e.jsx(T,{}),e.jsx("strong",{children:"Python 程序"}),e.jsxs("button",{type:"button",onClick:g,disabled:m,children:[m?e.jsx($,{className:"spin"}):e.jsx(O,{}),m?"运行中":"运行代码"]})]}),e.jsx("textarea",{value:p,onChange:j=>k(j.target.value),spellCheck:!1}),e.jsx("pre",{children:_})]}),e.jsxs("aside",{className:"homework-upload-card",children:[e.jsxs("h2",{children:[e.jsx(X,{})," 添加作业材料"]}),e.jsxs("label",{children:["作业说明",e.jsx("textarea",{rows:4,value:y,onChange:j=>o(j.target.value),placeholder:"说说你的思路或遇到的问题…"})]}),e.jsxs("div",{className:"upload-limits",children:[e.jsxs("span",{children:[e.jsx(Te,{})," 照片 ",s.length,"/10"]}),e.jsxs("span",{children:[e.jsx(Re,{})," 视频 ",b?1:0,"/1"]})]}),e.jsxs("label",{className:"homework-drop",children:[e.jsx(J,{}),e.jsx("strong",{children:"选择照片"}),e.jsx("small",{children:"最多 10 张"}),e.jsx("input",{hidden:!0,multiple:!0,type:"file",accept:"image/*",onChange:j=>t(j.target.files)})]}),s.length>0&&e.jsx("div",{className:"homework-photo-preview",children:E.map((j,M)=>e.jsxs("div",{children:[e.jsx("img",{src:j,alt:"作业预览"}),e.jsx("button",{type:"button",onClick:()=>h(L=>L.filter((rs,ie)=>ie!==M)),children:"×"})]},j))}),e.jsxs("label",{className:"homework-drop video",children:[e.jsx(He,{}),e.jsx("strong",{children:b?b.name:"选择视频"}),e.jsx("small",{children:"1 个，最长 5 分钟，最大 200MB"}),e.jsx("input",{hidden:!0,type:"file",accept:"video/*",onChange:j=>f(j.target.files?.[0])})]}),e.jsxs("button",{type:"button",className:"submit-homework",onClick:N,children:[e.jsx(q,{})," 提交作业"]})]})]})]})}function Je(l){return new Date(l).toLocaleString("zh-CN",{month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit"})}function es({studentId:l,studentName:i,onBack:d}){const[n,r]=c.useState(C),[x,p]=c.useState(!1),[k,y]=c.useState(null),[o,s]=c.useState({}),[h,b]=c.useState({}),S=c.useMemo(()=>n.plazaPosts.filter(t=>t.approved),[n]),_=n.plazaPosts.filter(t=>t.studentId===l&&!t.approved),u=t=>{H(t),r(t)},m=t=>{const f=C(),g=f.plazaPosts.find(N=>N.id===t);g&&(g.likedBy=g.likedBy.includes(l)?g.likedBy.filter(N=>N!==l):[...g.likedBy,l],u(f))},a=t=>{const f=h[t]?.trim();if(!f)return;const g=C();g.plazaPosts.find(N=>N.id===t)?.comments.push({id:B("comment"),studentId:l,studentName:i,content:f,createdAt:new Date().toISOString()}),u(g),b(N=>({...N,[t]:""}))},v=(t,f)=>{const g=C(),N=g.plazaPosts.find(j=>j.id===t);N&&(N.comments=N.comments.filter(j=>j.id!==f)),u(g)},P=async t=>{y(t.id),s(f=>({...f,[t.id]:"正在启动 Python…"}));try{const f=await Z(t.code,g=>s(N=>({...N,[t.id]:g})));s(g=>({...g,[t.id]:f}))}catch(f){s(g=>({...g,[t.id]:`运行出错：${f instanceof Error?f.message:String(f)}`}))}finally{y(null)}},E=t=>{const f=C(),g=f.activities.find(N=>N.id===t);g&&(g.registeredStudentIds=g.registeredStudentIds.includes(l)?g.registeredStudentIds.filter(N=>N!==l):[...g.registeredStudentIds,l],u(f))};return e.jsxs("main",{className:"student-module-page",children:[e.jsx(K,{icon:Q,label:"CREATIVE SQUARE",title:"交流广场",description:"分享代码与作品，看看同学们正在创造什么。",onBack:d}),e.jsxs("div",{className:"square-toolbar",children:[e.jsxs("div",{children:[e.jsx(se,{}),e.jsx("span",{children:"优秀作品经过老师审核后展示"})]}),e.jsxs("button",{type:"button",onClick:()=>p(!0),children:[e.jsx(he,{}),"发布新作品"]})]}),_.length>0&&e.jsxs("section",{className:"pending-posts",children:[e.jsx("strong",{children:"我的待审核作品"}),_.map(t=>e.jsxs("span",{children:[t.title,e.jsx("em",{children:"等待老师审核"})]},t.id))]}),e.jsxs("div",{className:"square-layout",children:[e.jsx("section",{className:"post-feed",children:S.map(t=>e.jsxs("article",{className:"plaza-post",children:[e.jsxs("header",{children:[e.jsx("span",{children:t.studentName.slice(-1)}),e.jsxs("div",{children:[e.jsx("strong",{children:t.studentName}),e.jsxs("small",{children:[new Date(t.createdAt).toLocaleDateString("zh-CN")," · Python 作品"]})]}),e.jsx("i",{children:"已审核"})]}),e.jsx("h2",{children:t.title}),e.jsx("p",{children:t.description}),t.code&&e.jsxs("div",{className:"post-code",children:[e.jsxs("div",{children:[e.jsx(T,{}),e.jsx("span",{children:"作品代码"}),e.jsxs("button",{type:"button",onClick:()=>P(t),disabled:k===t.id,children:[k===t.id?e.jsx($,{className:"spin"}):e.jsx(O,{}),"运行作品"]})]}),e.jsx("pre",{children:t.code}),o[t.id]&&e.jsx("output",{children:o[t.id]})]}),e.jsxs("div",{className:"post-actions",children:[e.jsxs("button",{type:"button",className:t.likedBy.includes(l)?"liked":"",onClick:()=>m(t.id),children:[e.jsx(ze,{})," ",t.likedBy.length]}),e.jsxs("span",{children:[e.jsx(Q,{})," ",t.comments.length]})]}),e.jsxs("div",{className:"post-comments",children:[t.comments.map(f=>e.jsxs("div",{children:[e.jsx("strong",{children:f.studentName}),e.jsx("p",{children:f.content}),f.studentId===l&&e.jsx("button",{type:"button",onClick:()=>v(t.id,f.id),children:"删除"})]},f.id)),e.jsxs("form",{onSubmit:f=>{f.preventDefault(),a(t.id)},children:[e.jsx("input",{value:h[t.id]||"",onChange:f=>b(g=>({...g,[t.id]:f.target.value})),placeholder:"友善地说点什么…"}),e.jsx("button",{children:e.jsx(q,{})})]})]})]},t.id))}),e.jsxs("aside",{className:"activity-rail",children:[e.jsxs("div",{className:"activity-title",children:[e.jsx(re,{}),e.jsxs("div",{children:[e.jsx("small",{children:"ACTIVITIES"}),e.jsx("strong",{children:"比赛与活动"})]})]}),n.activities.map(t=>e.jsxs("article",{children:[e.jsxs("span",{children:[e.jsx(Se,{})," ",t.date]}),e.jsx("h3",{children:t.title}),e.jsx("p",{children:t.description}),t.registrationType==="external"?e.jsxs("a",{href:t.externalUrl,target:"_blank",rel:"noreferrer",children:["查看活动 ",e.jsx(ue,{})]}):e.jsx("button",{type:"button",className:t.registeredStudentIds.includes(l)?"registered":"",onClick:()=>E(t.id),children:t.registeredStudentIds.includes(l)?e.jsxs(e.Fragment,{children:[e.jsx(xe,{}),"已报名"]}):e.jsxs(e.Fragment,{children:[e.jsx(me,{}),"站内报名"]})})]},t.id))]})]}),x&&e.jsx(ss,{studentId:l,studentName:i,onClose:()=>p(!1),onCreated:()=>{r(C()),p(!1)}})]})}function ss({studentId:l,studentName:i,onClose:d,onCreated:n}){const[r,x]=c.useState({title:"",description:"",code:""}),[p,k]=c.useState([]),y=o=>{o.preventDefault();const s=C();s.plazaPosts.push({id:B("post"),studentId:l,studentName:i,...r,mediaNames:p.map(h=>h.name),approved:!1,createdAt:new Date().toISOString(),likedBy:[],comments:[]}),H(s),n()};return e.jsx("div",{className:"quest-modal-backdrop",onMouseDown:o=>{o.currentTarget===o.target&&d()},children:e.jsxs("form",{className:"create-post-modal",onSubmit:y,children:[e.jsxs("div",{children:[e.jsx("span",{children:"NEW CREATION"}),e.jsx("h2",{children:"发布新作品"}),e.jsx("p",{children:"提交后由老师审核，审核通过后会出现在交流广场。"})]}),e.jsxs("label",{children:["作品标题",e.jsx("input",{value:r.title,onChange:o=>x({...r,title:o.target.value}),required:!0,placeholder:"给作品起一个响亮的名字"})]}),e.jsxs("label",{children:["作品说明",e.jsx("textarea",{rows:3,value:r.description,onChange:o=>x({...r,description:o.target.value}),required:!0,placeholder:"介绍作品玩法和你的创作思路"})]}),e.jsxs("label",{children:["Python 代码",e.jsx("textarea",{rows:9,className:"post-code-input",value:r.code,onChange:o=>x({...r,code:o.target.value}),placeholder:"# 可以粘贴能够运行的 Python 代码"})]}),e.jsxs("label",{className:"post-file-picker",children:[e.jsx(J,{}),"选择图片或视频",e.jsx("input",{hidden:!0,multiple:!0,type:"file",accept:"image/*,video/*",onChange:o=>k(Array.from(o.target.files||[]).slice(0,10))})]}),p.length>0&&e.jsxs("p",{className:"selected-files",children:["已选择：",p.map(o=>o.name).join("、")]}),e.jsxs("div",{className:"create-post-actions",children:[e.jsx("button",{type:"button",onClick:d,children:"取消"}),e.jsxs("button",{type:"submit",children:[e.jsx(q,{}),"提交审核"]})]})]})})}const ts=[{id:"class",number:"01",title:"开始上课",caption:"进入课件 · 完成挑战",icon:ne,color:"orange",active:!0},{id:"test",number:"02",title:"测评",caption:"检验本领 · 突破自我",icon:Y,color:"cyan",active:!0},{id:"homework",number:"03",title:"上传作业",caption:"提交创作 · 等待点评",icon:Oe,color:"lime",active:!0},{id:"square",number:"04",title:"交流广场",caption:"分享作品 · 发现灵感",icon:Ue,color:"purple",active:!0}];function vs(){const l=oe(),i=ye(),[d,n]=c.useState("lobby"),[r,x]=c.useState(()=>i?V(i.studentId):{points:0,answeredQuestionIds:[],completedLessonIds:[],lessonProgress:{}}),[p,k]=c.useState(null),[y,o]=c.useState(""),[s,h]=c.useState(!1),b=r.points;if(c.useEffect(()=>{i||l("/student/login",{replace:!0})},[l,i]),c.useEffect(()=>{const _=u=>{if(!(u.origin!==window.location.origin||!i||!u.data?.type)){if(u.data.type==="growth-courseware:score"){const m=V(i.studentId),a=ge(i.studentId,u.data.questionId,u.data.correct?u.data.points:0);x(a),o(a.points>m.points?`答对了！积分 +${a.points-m.points}`:u.data.correct?"这道题已经获得过积分啦":"再想一想，你一定可以"),window.setTimeout(()=>o(""),2200);return}if(u.data.type==="growth-courseware:progress"){const m=V(i.studentId),a=be(i.studentId,u.data.lessonId,u.data.currentSlide,u.data.totalSlides,u.data.completed);x(a),u.data.completed&&!m.completedLessonIds.includes(u.data.lessonId)&&(o("关卡完成！下一节课已经解锁"),k({lessonId:u.data.lessonId,nonce:Date.now()}),window.setTimeout(()=>o(""),2600))}}};return window.addEventListener("message",_),()=>window.removeEventListener("message",_)},[i]),!i)return null;const S=()=>{ve(),l("/student/login",{replace:!0})};return e.jsxs("div",{className:"quest-app",children:[y&&e.jsxs("div",{className:"score-toast",children:[e.jsx(Fe,{})," ",y]}),e.jsxs("header",{className:"quest-topbar",children:[e.jsxs("button",{type:"button",className:"quest-brand",onClick:()=>n("lobby"),children:[e.jsx("span",{children:e.jsx(te,{})}),e.jsxs("div",{children:[e.jsx("strong",{children:"CODE QUEST"}),e.jsx("small",{children:"咱们班的成长记录"})]})]}),e.jsxs("div",{className:"quest-userbar",children:[e.jsxs("div",{className:"point-pill",children:[e.jsx(ae,{}),e.jsxs("span",{children:[e.jsx("small",{children:"我的积分"}),e.jsx("strong",{children:b})]})]}),e.jsxs("div",{className:"player-pill",children:[e.jsx("span",{children:e.jsx(we,{})}),e.jsxs("div",{children:[e.jsx("small",{children:"冒险玩家"}),e.jsx("strong",{children:i.studentName})]})]}),e.jsx("button",{type:"button",className:"quest-logout",title:"修改密码",onClick:()=>h(!0),children:e.jsx(pe,{})}),e.jsx("button",{type:"button",className:"quest-logout",title:"退出登录",onClick:S,children:e.jsx(je,{})})]})]}),d==="lobby"&&e.jsx(ns,{studentName:i.studentName,points:b,completedLessons:r.completedLessonIds.length,onOpen:n}),d==="classroom"&&e.jsx(as,{studentId:i.studentId,studentName:i.studentName,points:b,studentProgress:r,completionSignal:p,onBack:()=>n("lobby")}),d==="assessment"&&e.jsx(Ge,{studentId:i.studentId,onBack:()=>n("lobby")}),d==="homework"&&e.jsx(Ye,{studentId:i.studentId,studentName:i.studentName,onBack:()=>n("lobby")}),d==="square"&&e.jsx(es,{studentId:i.studentId,studentName:i.studentName,onBack:()=>n("lobby")}),s&&e.jsx(ls,{studentId:i.studentId,onClose:()=>h(!1)})]})}function ns({studentName:l,points:i,completedLessons:d,onOpen:n}){return e.jsxs("main",{className:"quest-lobby",children:[e.jsxs("section",{className:"lobby-hero",children:[e.jsxs("div",{children:[e.jsxs("span",{className:"hero-eyebrow",children:[e.jsx(se,{})," TODAY'S ADVENTURE"]}),e.jsxs("h1",{children:["晚上好，",l,e.jsx("br",{}),e.jsx("em",{children:"今天想挑战哪一关？"})]}),e.jsx("p",{children:"大胆尝试，错误只是通往答案的隐藏路线。"})]}),e.jsxs("div",{className:"hero-console","aria-hidden":"true",children:[e.jsxs("div",{className:"console-screen",children:[e.jsx(T,{}),e.jsx("span",{children:"READY?"}),e.jsx("i",{children:"_"})]}),e.jsx("span",{className:"console-button button-a"}),e.jsx("span",{className:"console-button button-b"}),e.jsx("span",{className:"console-cross",children:"+"})]})]}),e.jsxs("section",{className:"module-board",children:[e.jsxs("div",{className:"board-title",children:[e.jsx("span",{children:"CHOOSE A LEVEL"}),e.jsx("h2",{children:"冒险地图"}),e.jsx("p",{children:"四大板块已经开放，选择一项开始今天的挑战。"})]}),e.jsx("div",{className:"module-grid",children:ts.map(r=>e.jsxs("button",{type:"button",className:`quest-module module-${r.color} ${r.active?"":"is-locked"}`,onClick:r.active?()=>n(r.id==="class"?"classroom":r.id==="test"?"assessment":r.id):void 0,children:[e.jsx("span",{className:"module-number",children:r.number}),e.jsx("span",{className:"module-icon",children:e.jsx(r.icon,{})}),e.jsxs("span",{className:"module-copy",children:[e.jsx("strong",{children:r.title}),e.jsx("small",{children:r.caption})]}),r.active?e.jsx("span",{className:"module-go",children:e.jsx(O,{})}):e.jsxs("span",{className:"module-lock",children:[e.jsx(le,{})," 即将开放"]})]},r.id))})]}),e.jsxs("section",{className:"lobby-status",children:[e.jsxs("div",{children:[e.jsx(re,{}),e.jsxs("span",{children:[e.jsx("small",{children:"当前积分"}),e.jsx("strong",{children:i})]})]}),e.jsxs("div",{children:[e.jsx(ne,{}),e.jsxs("span",{children:[e.jsx("small",{children:"课程进度"}),e.jsxs("strong",{children:[d," / ",A.totalLessons]})]})]}),e.jsxs("div",{children:[e.jsx(Ve,{}),e.jsxs("span",{children:[e.jsx("small",{children:"班级排名"}),e.jsx("strong",{children:"第 5 名"})]})]}),e.jsxs("div",{className:"status-motto",children:[e.jsx("span",{children:"今日提示"}),e.jsx("p",{children:"把大问题拆成小问题，代码就会变简单。"})]})]})]})}function ls({studentId:l,onClose:i}){const[d,n]=c.useState(""),[r,x]=c.useState(""),[p,k]=c.useState(""),[y,o]=c.useState(""),s=h=>{if(h.preventDefault(),r.length<6)return o("新密码至少需要 6 位。");if(r!==p)return o("两次输入的新密码不一致。");if(!Ne(l,d,r))return o("当前密码不正确。");window.alert("密码修改成功，请使用新密码登录。"),i()};return e.jsx("div",{className:"quest-modal-backdrop",onMouseDown:h=>{h.currentTarget===h.target&&i()},children:e.jsxs("form",{className:"password-modal",onSubmit:s,children:[e.jsx("span",{children:e.jsx(Ce,{})}),e.jsx("h2",{children:"修改登录密码"}),e.jsx("p",{children:"忘记密码时，请联系老师在教师端重置。"}),e.jsxs("label",{children:["当前密码",e.jsx("input",{type:"password",value:d,onChange:h=>n(h.target.value),required:!0})]}),e.jsxs("label",{children:["新密码",e.jsx("input",{type:"password",value:r,onChange:h=>x(h.target.value),required:!0})]}),e.jsxs("label",{children:["再次输入新密码",e.jsx("input",{type:"password",value:p,onChange:h=>k(h.target.value),required:!0})]}),y&&e.jsx("em",{children:y}),e.jsxs("div",{children:[e.jsx("button",{type:"button",onClick:i,children:"取消"}),e.jsx("button",{type:"submit",children:"确认修改"})]})]})})}function as({studentId:studentId,studentName:l,points:i,studentProgress:d,completionSignal:n,onBack:r}){const[x,p]=c.useState("lesson-1"),k=c.useRef(null),[y,o]=c.useState(!1),s=I.find(a=>a.id===x)??I[0],h=I.map((a,v)=>{const P=d.completedLessonIds.includes(a.id),E=v<3||d.completedLessonIds.includes(I[v-1].id);return{...a,status:P?"completed":E?"current":"locked"}}),b=d.lessonProgress[s.id],S=s.id==="lesson-1"?"/courseware/no.1/index.html":s.id==="lesson-2"?"/courseware/no.2/index.html":s.id==="lesson-3"?`/courseware/no.3/index.html?studentId=${encodeURIComponent(studentId)}&studentName=${encodeURIComponent(l)}&points=${i}`:"/demo-courseware.html",_=c.useMemo(()=>[...ke,{id:"me",name:l,points:i,color:"#83ed9b",me:!0}].sort((a,v)=>v.points-a.points),[i,l]);c.useEffect(()=>{const a=()=>o(document.fullscreenElement===k.current);return document.addEventListener("fullscreenchange",a),()=>document.removeEventListener("fullscreenchange",a)},[]),c.useEffect(()=>{if(!n||n.lessonId!==x)return;const a=I.findIndex(E=>E.id===x),v=I[a+1];if(!v)return;const P=window.setTimeout(()=>p(v.id),1500);return()=>window.clearTimeout(P)},[n,x]);const u=async()=>{document.fullscreenElement?await document.exitFullscreen():await k.current?.requestFullscreen()},m=d.completedLessonIds.length;return e.jsxs("main",{className:"classroom-page",children:[e.jsxs("div",{className:"classroom-heading",children:[e.jsxs("button",{type:"button",onClick:r,children:[e.jsx(F,{})," 返回冒险大厅"]}),e.jsxs("div",{children:[e.jsx("span",{children:"LEVEL SELECT"}),e.jsx("h1",{children:A.name}),e.jsxs("p",{children:[A.teacher," · 已完成 ",m,"/",A.totalLessons," 节课"]})]}),e.jsxs("div",{className:"class-progress-ring",children:[e.jsxs("strong",{children:[Math.round(m/A.totalLessons*100),"%"]}),e.jsx("small",{children:"课程进度"})]})]}),e.jsxs("div",{className:"classroom-layout",children:[e.jsxs("aside",{className:"lesson-map",children:[e.jsxs("div",{className:"map-title",children:[e.jsx("span",{children:e.jsx(te,{})}),e.jsxs("div",{children:[e.jsx("small",{children:"COURSE MAP"}),e.jsx("strong",{children:"课程关卡"})]})]}),h.map(a=>{const v=d.lessonProgress[a.id];return e.jsxs("button",{type:"button",disabled:a.status==="locked",className:`${a.id===x?"active":""} ${a.status}`,onClick:()=>p(a.id),children:[e.jsx("span",{children:a.status==="locked"?e.jsx(le,{}):a.status==="completed"?e.jsx(R,{}):a.sequence}),e.jsxs("div",{children:[e.jsx("strong",{children:a.title}),e.jsx("small",{children:v?.completed?"已经完成 · 点击可以复习":v?`课件进度 ${v.currentSlide}/${v.totalSlides}`:a.subtitle}),v&&e.jsx("b",{className:"lesson-mini-progress",children:e.jsx("i",{style:{width:`${v.percent}%`}})})]}),e.jsx(ee,{})]},a.id)})]}),e.jsxs("section",{className:"lesson-stage",children:[e.jsxs("div",{className:"stage-top",children:[e.jsxs("div",{children:[e.jsxs("span",{children:["LEVEL ",String(s.sequence).padStart(2,"0")]}),e.jsx("h2",{children:s.title}),e.jsxs("p",{children:[s.subtitle,"。认真观看课件，答题积分会自动记录。"]})]}),e.jsxs("div",{className:"stage-reward",children:[e.jsx(ae,{}),e.jsxs("span",{children:[e.jsx("small",{children:"本课奖励"}),e.jsx("strong",{children:"闯关积分"})]})]})]}),e.jsxs("div",{className:"courseware-frame",ref:k,children:[e.jsxs("div",{className:"frame-label",children:[e.jsx("i",{}),e.jsx("span",{children:"互动课件"}),e.jsx("small",{children:b?`已学习 ${b.currentSlide}/${b.totalSlides} 页 · ${b.percent}%`:"方向键或空格翻页 · 答题结果自动记录"}),e.jsxs("button",{type:"button",className:"frame-fullscreen",onClick:u,title:y?"退出全屏":"全屏播放课件",children:[y?e.jsx($e,{}):e.jsx(qe,{}),e.jsx("b",{children:y?"退出全屏":"全屏播放"})]})]}),e.jsx("iframe",{title:`${s.title}互动课件`,src:S,allow:"fullscreen",allowFullScreen:!0},s.id)]}),e.jsx(Qe,{})]}),e.jsxs("aside",{className:"leaderboard",children:[e.jsxs("div",{className:"rank-heading",children:[e.jsx(Ie,{}),e.jsxs("div",{children:[e.jsx("small",{children:"LIVE RANKING"}),e.jsx("strong",{children:"实时排行榜"})]}),e.jsx("span",{children:"本节课"})]}),e.jsx("div",{className:"rank-podium",children:_.slice(0,3).map((a,v)=>e.jsxs("div",{className:`rank-${v+1}`,children:[e.jsx("span",{style:{background:a.color},children:a.name.slice(-1)}),e.jsx("strong",{children:a.name}),e.jsxs("small",{children:[a.points," 分"]}),e.jsx("i",{children:v+1})]},a.id))}),e.jsx("ol",{children:_.slice(3).map((a,v)=>e.jsxs("li",{className:"me"in a&&a.me?"is-me":"",children:[e.jsx("b",{children:v+4}),e.jsx("span",{style:{background:a.color},children:a.name.slice(-1)}),e.jsxs("strong",{children:[a.name,"me"in a&&a.me?"（我）":""]}),e.jsx("em",{children:a.points})]},a.id))}),e.jsxs("div",{className:"rank-note",children:[e.jsx(fe,{}),e.jsx("p",{children:"每道题第一次答对才会获得积分，重复作答不会刷分。"})]})]})]})]})}export{vs as default};
