#!/usr/bin/env python3
from pathlib import Path
import shutil
from datetime import datetime

app_path = Path('/opt/growth-journal-api/app.py')
source = app_path.read_text(encoding='utf-8')
stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
backup = app_path.with_name(f'app.py.backup-points-{stamp}')
shutil.copy2(app_path, backup)

schema_marker = '    @app.get("/api/health")\n'
schema_block = '''    def ensure_points_schema() -> None:
        db = get_db()
        columns = {row["name"] for row in db.execute("pragma table_info(student_accounts)").fetchall()}
        if "points" not in columns:
            db.execute("alter table student_accounts add column points integer not null default 0")
        db.execute(
            """create table if not exists point_events (
                id text primary key,
                account_id text not null references student_accounts(id) on delete cascade,
                delta integer not null,
                reason text not null default '',
                source_id text,
                created_at text not null,
                unique(account_id, source_id)
            )"""
        )
        db.commit()

    ensure_points_schema()

'''
if 'def ensure_points_schema()' not in source:
    if schema_marker not in source:
        raise SystemExit('health route marker not found')
    source = source.replace(schema_marker, schema_block + schema_marker, 1)

accounts_line = '        accounts = [account_json(row) for row in rows]\n'
accounts_enrich = accounts_line + '        for item, row in zip(accounts, rows):\n            item["points"] = int(row["points"] or 0)\n'
if 'item["points"] = int(row["points"] or 0)' not in source:
    if accounts_line not in source:
        raise SystemExit('account list marker not found')
    source = source.replace(accounts_line, accounts_enrich, 1)

route_marker = '    @app.post("/api/media/upload")\n'
routes = '''    @app.get("/api/leaderboard")
    def leaderboard():
        student = student_from_cookie()
        if not student:
            return jsonify({"error": "学生登录已失效，请重新登录。"}), 401
        rows = get_db().execute(
            "select id, student_name, points from student_accounts where active = 1 order by points desc, student_name collate nocase"
        ).fetchall()
        return jsonify({"accounts": [
            {"id": row["id"], "studentName": row["student_name"], "points": int(row["points"] or 0)}
            for row in rows
        ]})

    @app.post("/api/student/points/award")
    def student_points_award():
        student = student_from_cookie()
        if not student:
            return jsonify({"error": "学生登录已失效，请重新登录。"}), 401
        body = json_body()
        question_id = str(body.get("questionId", "")).strip()[:160]
        points = max(0, min(100, int(body.get("points") or 0)))
        reason = str(body.get("reason", "课件答题")).strip()[:120]
        if not question_id or points <= 0:
            return jsonify({"error": "积分请求无效。"}), 400
        db = get_db()
        try:
            db.execute(
                "insert into point_events (id, account_id, delta, reason, source_id, created_at) values (?, ?, ?, ?, ?, ?)",
                (str(uuid.uuid4()), student["id"], points, reason, question_id, iso_now()),
            )
            db.execute("update student_accounts set points = points + ?, updated_at = ? where id = ?", (points, iso_now(), student["id"]))
            db.commit()
        except sqlite3.IntegrityError:
            db.rollback()
        row = db.execute("select points from student_accounts where id = ?", (student["id"],)).fetchone()
        return jsonify({"points": int(row["points"] or 0), "awarded": True})

    @app.patch("/api/admin/student-accounts/<account_id>/points")
    @require_admin
    def adjust_account_points(account_id: str):
        body = json_body()
        try:
            delta = int(body.get("delta") or 0)
        except (TypeError, ValueError):
            return jsonify({"error": "积分必须是整数。"}), 400
        if delta == 0 or abs(delta) > 1000:
            return jsonify({"error": "单次积分调整范围为 -1000 到 1000。"}), 400
        reason = str(body.get("reason", "教师调整")).strip()[:120]
        db = get_db()
        row = db.execute("select points from student_accounts where id = ?", (account_id,)).fetchone()
        if not row:
            return jsonify({"error": "学生账号不存在。"}), 404
        old_points = int(row["points"] or 0)
        new_points = max(0, old_points + delta)
        actual_delta = new_points - old_points
        db.execute("update student_accounts set points = ?, updated_at = ? where id = ?", (new_points, iso_now(), account_id))
        db.execute(
            "insert into point_events (id, account_id, delta, reason, source_id, created_at) values (?, ?, ?, ?, ?, ?)",
            (str(uuid.uuid4()), account_id, actual_delta, reason, None, iso_now()),
        )
        db.commit()
        return jsonify({"ok": True, "points": new_points, "delta": actual_delta})

    @app.get("/api/admin/point-events")
    @require_admin
    def list_point_events():
        rows = get_db().execute(
            """select e.id, e.account_id, a.student_name, e.delta, e.reason, e.created_at
               from point_events e join student_accounts a on a.id = e.account_id
               order by e.created_at desc limit 200"""
        ).fetchall()
        return jsonify({"events": [dict(row) for row in rows]})

'''
if '/api/student/points/award' not in source:
    if route_marker not in source:
        raise SystemExit('media route marker not found')
    source = source.replace(route_marker, routes + route_marker, 1)

app_path.write_text(source, encoding='utf-8')
print(f'patched {app_path}')
print(f'backup {backup}')
