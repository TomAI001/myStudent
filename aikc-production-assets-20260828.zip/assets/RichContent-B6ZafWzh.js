import{j as e}from"./index-Bm8Wdtd2.js";function o({html:t,className:n=""}){return e.jsx("div",{className:`rich-content ${n}`,dangerouslySetInnerHTML:{__html:t}})}export{o as R};
