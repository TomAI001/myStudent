from __future__ import annotations

import json
import secrets
import sqlite3
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Callable
from zoneinfo import ZoneInfo

from flask import current_app, g, jsonify, request
from werkzeug.utils import secure_filename


SCALE_OPTIONS = [
    {"value": 1, "label": "完全不像我"},
    {"value": 2, "label": "比较不像我"},
    {"value": 3, "label": "一半像、一半不像"},
    {"value": 4, "label": "比较像我"},
    {"value": 5, "label": "非常像我"},
]


DIMENSIONS = [
    {
        "id": "linguistic", "name": "语言智能", "color": "#ff7a45",
        "facets": ["阅读理解", "口语表达", "书面表达", "倾听感受", "词语运用"],
        "questions": [
            "我喜欢阅读故事、科普文章或电子书。", "我能比较快地读懂一段文字的主要意思。",
            "我喜欢把自己的想法讲给别人听。", "我能有条理地讲清楚一件事情。",
            "我愿意写日记、故事、笔记或学习总结。", "我能用文字准确表达自己的感受和观点。",
            "别人说话时，我能耐心听完并抓住重点。", "我能从说话的语气中感受到对方的情绪。",
            "我对新词、成语、双关语或文字游戏感兴趣。", "遇到不同场合时，我会调整自己的表达方式。",
        ],
    },
    {
        "id": "logical", "name": "逻辑数学智能", "color": "#f5b82e",
        "facets": ["分析推理", "归纳整理", "灵活演绎", "数字运算", "实验验证"],
        "questions": [
            "遇到难题时，我喜欢先找出已知条件和关键线索。", "我能根据线索一步步推断出合理答案。",
            "我喜欢把零散信息分类整理并找出共同规律。", "我做完练习后会总结同类题的解题方法。",
            "如果一种方法行不通，我会尝试从另一个角度解决。", "我能把学过的规则用到新的问题中。",
            "我对数字、计算、统计或数学游戏感兴趣。", "日常需要估算或比较数量时，我通常比较准确。",
            "我喜欢通过动手试验来验证自己的猜想。", "得到答案后，我愿意检查过程是否真的成立。",
        ],
    },
    {
        "id": "natural", "name": "自然观察智能", "color": "#55b96b",
        "facets": ["细致观察", "主动探索", "特征识别", "分类整理", "环境关怀"],
        "questions": [
            "我容易注意到周围环境中细小的变化。", "观察动植物或自然现象时，我能发现很多细节。",
            "看到不熟悉的自然现象时，我会想知道原因。", "我喜欢到户外探索并记录自己的发现。",
            "我能根据外形、习性或特点辨认不同事物。", "我善于发现两个相似事物之间的差别。",
            "我喜欢把物品、资料或观察结果分门别类。", "整理东西时，我通常能设计清楚的分类方法。",
            "我关心动植物、天气、环境和资源节约。", "我愿意为保护环境做一些力所能及的事情。",
        ],
    },
    {
        "id": "spatial", "name": "视觉空间智能", "color": "#35a7db",
        "facets": ["图像记忆", "色彩感知", "空间想象", "绘图表达", "结构组装"],
        "questions": [
            "我看过地图、图表或图片后能记住不少细节。", "学习时，图像和示意图能帮助我更快理解。",
            "我容易注意到颜色搭配和明暗变化。", "我喜欢用颜色区分重点或设计作品。",
            "我能在脑海中想象物体旋转或换一个方向后的样子。", "我看平面图时能想象出真实空间的大致布局。",
            "我喜欢画图、设计图标或用图形表达想法。", "我能把脑海里的场景画出大致结构。",
            "我喜欢拼图、积木、模型或组装物品。", "面对复杂结构时，我能看懂各部分怎样连接。",
        ],
    },
    {
        "id": "musical", "name": "音乐智能", "color": "#9a67d8",
        "facets": ["节奏敏感", "旋律感受", "音乐鉴赏", "声音表现", "音乐创造"],
        "questions": [
            "听到音乐时，我容易跟着节拍打拍子。", "我能发现一段节奏中突然出现的变化。",
            "我听过几次后通常能记住一段旋律。", "我能分辨旋律的高低、快慢和情绪。",
            "我愿意主动听不同风格的音乐。", "我能说出自己喜欢或不喜欢一段音乐的原因。",
            "我喜欢唱歌、演奏乐器或用声音表达情绪。", "在人前进行音乐表演时，我愿意尝试。",
            "我有时会自己哼出新的旋律或设计节奏。", "我喜欢给故事、视频或游戏选择合适的配乐。",
        ],
    },
    {
        "id": "bodily", "name": "肢体动觉智能", "color": "#ef6a8c",
        "facets": ["触觉操作", "快速反应", "身体平衡", "动作控制", "节奏律动"],
        "questions": [
            "我喜欢通过亲手操作来学习新东西。", "需要精细动手时，我通常能控制好力度和位置。",
            "球类或反应游戏中，我能较快做出动作。", "面对突然变化的动作任务时，我能及时调整。",
            "我在跑跳、转身或单脚站立时能保持平衡。", "我学习新的体育动作时身体协调性较好。",
            "我能准确模仿别人示范的动作。", "我能有意识地控制动作的方向、速度和幅度。",
            "音乐响起时，我能自然地跟随节奏活动身体。", "我喜欢舞蹈、律动或有节奏的运动。",
        ],
    },
    {
        "id": "intrapersonal", "name": "个人内省智能", "color": "#2f9a83",
        "facets": ["自我洞察", "反思调整", "目标自律", "同理感受", "关怀价值"],
        "questions": [
            "我清楚自己比较擅长和需要提高的地方。", "我能觉察自己情绪变化背后的原因。",
            "事情没有做好时，我会回想原因并寻找改进办法。", "收到建议后，我能挑出对自己有帮助的部分。",
            "我会为学习任务设定目标并努力完成。", "即使暂时没有人提醒，我也能推进自己的计划。",
            "我能想象别人在某种处境中的感受。", "和别人意见不同时，我愿意理解对方为什么这样想。",
            "做决定时，我会考虑这件事对自己和他人的影响。", "我愿意帮助遇到困难的人，并尊重彼此差异。",
        ],
    },
    {
        "id": "interpersonal", "name": "人际沟通智能", "color": "#7fbd49",
        "facets": ["了解他人", "情感共鸣", "组织领导", "团队协作", "沟通协调"],
        "questions": [
            "我能较快了解同学的兴趣和做事方式。", "我容易发现团队中谁需要帮助或鼓励。",
            "别人开心或难过时，我能做出合适的回应。", "朋友向我倾诉时，我能让对方感到被理解。",
            "小组活动中，我愿意组织大家明确目标和分工。", "出现混乱时，我能带着大家一起找到下一步。",
            "我愿意承担团队任务并按约定完成。", "与别人合作时，我能分享信息并配合调整。",
            "在人群中，我通常能找到合适的人沟通交流。", "出现分歧时，我会尝试把双方的想法说清楚。",
        ],
    },
]


DIMENSION_GUIDANCE = {
    "linguistic": "多用阅读批注、复述、写学习日志和向他人讲解的方式巩固知识。",
    "logical": "把复杂任务拆成步骤，使用表格、流程图和错题归纳训练推理能力。",
    "natural": "通过观察记录、分类比较和小实验，把抽象知识连接到真实世界。",
    "spatial": "多使用思维导图、示意图、模型和颜色标记，让知识变得可视化。",
    "musical": "可用节奏朗读、押韵口诀和舒缓背景音乐帮助记忆与保持专注。",
    "bodily": "安排动手实践、角色演示和短时运动间隔，让身体参与学习过程。",
    "intrapersonal": "设定可完成的小目标，每周复盘一次进步、困难和下一步计划。",
    "interpersonal": "通过小组讨论、同伴互评和合作项目，在交流中深化理解。",
}


POPULAR_POKI_GAMES = [
    ("Subway Surfers", "https://poki.com/g/subway-surfers", "跑酷闯关"),
    ("Monkey Mart", "https://poki.com/g/monkey-mart", "经营挑战"),
    ("Level Devil", "https://poki.com/g/level-devil", "反应闯关"),
    ("Brain Test: Tricky Puzzles", "https://poki.com/g/brain-test-tricky-puzzles", "脑洞解谜"),
    ("Temple Run 2", "https://poki.com/g/temple-run-2", "跑酷冒险"),
    ("Fruit Ninja", "https://poki.com/g/fruit-ninja", "敏捷挑战"),
    ("Happy Glass", "https://poki.com/g/happy-glass", "物理解谜"),
    ("Slice Master", "https://poki.com/g/slice-master", "轻松闯关"),
    ("Drive Mad", "https://poki.com/g/drive-mad", "驾驶挑战"),
    ("Tunnel Rush", "https://poki.com/g/tunnel-rush", "反应挑战"),
    ("Master Chess", "https://poki.com/g/master-chess", "棋类益智"),
    ("Blocky Blast Puzzle", "https://poki.com/g/blocky-blast-puzzle", "方块解谜"),
    ("Penalty Shooters 2", "https://poki.com/g/penalty-shooters-2", "足球竞技"),
    ("2048", "https://poki.com/g/2048", "数字益智"),
    ("Dino Game", "https://poki.com/g/dino-game", "经典闯关"),
    ("Ping Pong Go!", "https://poki.com/g/ping-pong-go", "乒乓挑战"),
    ("Water Color Sort", "https://poki.com/g/water-color-sort", "颜色解谜"),
    ("Anycolor", "https://poki.com/g/anycolor", "创意涂色"),
]


def _questions() -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    number = 1
    for dimension in DIMENSIONS:
        for offset, text in enumerate(dimension["questions"]):
            items.append({
                "id": f"q{number}", "number": number, "text": text,
                "dimension": dimension["id"], "dimensionName": dimension["name"],
                "facet": dimension["facets"][offset // 2],
            })
            number += 1
    return items


QUESTIONS = _questions()


def _build_report(answers: dict[str, Any]) -> dict[str, Any]:
    result = []
    for dimension in DIMENSIONS:
        related = [item for item in QUESTIONS if item["dimension"] == dimension["id"]]
        facets = []
        for facet in dimension["facets"]:
            values = [int(answers[item["id"]]) for item in related if item["facet"] == facet]
            facets.append({"name": facet, "score": round(sum(values) / len(values), 1)})
        all_values = [int(answers[item["id"]]) for item in related]
        result.append({
            "id": dimension["id"], "name": dimension["name"], "color": dimension["color"],
            "score": round(sum(all_values) / len(all_values) * 20), "facets": facets,
            "guidance": DIMENSION_GUIDANCE[dimension["id"]],
        })
    ranked = sorted(result, key=lambda item: (-item["score"], item["name"]))
    strengths = ranked[:3]
    growth = sorted(result, key=lambda item: (item["score"], item["name"]))[:3]
    top_ids = {item["id"] for item in strengths}
    if {"linguistic", "interpersonal"} & top_ids:
        profile = "交流表达型学习者"
        profile_tip = "在讨论、复述和向他人讲解中，你更容易把知识真正变成自己的。"
    elif {"logical", "natural"} & top_ids:
        profile = "探索推理型学习者"
        profile_tip = "通过问题、规律、实验和真实案例学习，会让你更快进入状态。"
    elif {"spatial", "bodily"} & top_ids:
        profile = "视觉实践型学习者"
        profile_tip = "图像、模型和亲手操作能帮助你建立清晰、牢固的理解。"
    else:
        profile = "节奏反思型学习者"
        profile_tip = "给自己安静思考、整理和按节奏重复练习的空间，学习效果会更好。"
    directions = []
    direction_map = {
        "linguistic": "阅读写作、演讲表达、语言学习与内容创作",
        "logical": "数学思维、编程、科学探究与策略设计",
        "natural": "生命科学、环境观察、实验研究与户外探索",
        "spatial": "绘画设计、建筑模型、影像制作与工程制图",
        "musical": "音乐欣赏、演唱演奏、节奏训练与音频创作",
        "bodily": "体育运动、手工制作、表演实践与机器人搭建",
        "intrapersonal": "自主学习、目标管理、创意写作与深度研究",
        "interpersonal": "团队项目、组织策划、公共表达与合作实践",
    }
    for item in strengths:
        directions.append({"name": item["name"], "text": direction_map[item["id"]]})
    return {
        "version": 1, "dimensions": result,
        "strengths": [{"id": item["id"], "name": item["name"], "score": item["score"], "guidance": item["guidance"]} for item in strengths],
        "growthAreas": [{"id": item["id"], "name": item["name"], "score": item["score"], "guidance": item["guidance"]} for item in growth],
        "learningProfile": {"name": profile, "tip": profile_tip},
        "directions": directions,
        "disclaimer": "本报告用于了解学习偏好与优势组合，不是智力高低判断，也不作为医学、心理诊断或升学定论。",
    }


def register_admissions_rewards(
    app: Any,
    *,
    get_db: Callable,
    require_admin: Callable,
    require_student: Callable,
    require_parent: Callable,
    account_json: Callable,
    json_body: Callable,
    iso_now: Callable,
    compress_image_file: Callable,
) -> None:
    def purge_legacy_community(db: sqlite3.Connection) -> None:
        """Permanently remove retired square data and only its explicitly linked uploads."""
        legacy_tables = [
            row["name"] for row in db.execute(
                "select name from sqlite_master where type='table' and (lower(name) like '%plaza%' or lower(name) like '%community%')"
            ).fetchall()
        ]
        attachment_values: list[Any] = []
        for table in legacy_tables:
            quoted_table = '"' + table.replace('"', '""') + '"'
            columns = [row["name"] for row in db.execute(f"pragma table_info({quoted_table})").fetchall()]
            relevant = [name for name in columns if any(key in name.lower() for key in ("attachment", "media", "image", "file", "path"))]
            if relevant:
                selected = ",".join('"' + name.replace('"', '""') + '"' for name in relevant)
                for row in db.execute(f"select {selected} from {quoted_table}").fetchall():
                    attachment_values.extend(row[name] for name in relevant if row[name])

        tokens: set[str] = set()
        def collect(value: Any) -> None:
            if isinstance(value, dict):
                for nested in value.values(): collect(nested)
            elif isinstance(value, list):
                for nested in value: collect(nested)
            elif isinstance(value, str):
                stripped = value.strip()
                if not stripped: return
                try: decoded = json.loads(stripped)
                except (json.JSONDecodeError, TypeError): tokens.add(stripped)
                else:
                    if decoded == value: tokens.add(stripped)
                    else: collect(decoded)
        for value in attachment_values: collect(value)

        upload_root = Path(current_app.config["UPLOAD_ROOT"]).resolve()
        linked_rows = []
        linked_media = []
        shared_exists = db.execute("select 1 from sqlite_master where type='table' and name='shared_files'").fetchone()
        if shared_exists and tokens:
            placeholders = ",".join("?" for _ in tokens)
            linked_rows = db.execute(
                f"select id,stored_path from shared_files where id in ({placeholders}) or stored_path in ({placeholders})",
                [*tokens, *tokens],
            ).fetchall()
        media_exists = db.execute("select 1 from sqlite_master where type='table' and name='media_uploads'").fetchone()
        if media_exists and tokens:
            placeholders = ",".join("?" for _ in tokens)
            linked_media = db.execute(
                f"select id,relative_path from media_uploads where id in ({placeholders}) or relative_path in ({placeholders})",
                [*tokens, *tokens],
            ).fetchall()
        relative_paths = {str(row["stored_path"]) for row in linked_rows if row["stored_path"]}
        relative_paths.update(str(row["relative_path"]) for row in linked_media if row["relative_path"])
        for token in tokens:
            normalized = token.split("/uploads/", 1)[-1] if "/uploads/" in token else token
            if not normalized.startswith(("http://", "https://")):
                relative_paths.add(normalized.lstrip("/\\"))
        for relative in relative_paths:
            target = (upload_root / relative).resolve()
            try: target.relative_to(upload_root)
            except ValueError: continue
            if target.is_file(): target.unlink(missing_ok=True)

        if linked_rows:
            file_ids = [str(row["id"]) for row in linked_rows]
            placeholders = ",".join("?" for _ in file_ids)
            db.execute(f"delete from class_resource_assignments where resource_id in ({placeholders})", [f"file:{item}" for item in file_ids])
            db.execute(f"delete from resource_library where id in ({placeholders})", [f"file:{item}" for item in file_ids])
            db.execute(f"delete from shared_files where id in ({placeholders})", file_ids)
        if linked_media:
            media_ids = [str(row["id"]) for row in linked_media]
            placeholders = ",".join("?" for _ in media_ids)
            db.execute(f"delete from media_uploads where id in ({placeholders})", media_ids)

        db.execute("delete from class_resource_assignments where resource_id='community:class-square'")
        db.execute("delete from resource_library where id='community:class-square' or kind='community'")
        for table in sorted(legacy_tables, key=lambda name: ("post" in name.lower(), name)):
            quoted_table = '"' + table.replace('"', '""') + '"'
            db.execute(f"drop table if exists {quoted_table}")

    def init_schema() -> None:
        db = get_db()
        columns = {row["name"] for row in db.execute("pragma table_info(student_accounts)").fetchall()}
        if "lifetime_points" not in columns:
            db.execute("alter table student_accounts add column lifetime_points integer not null default 0")
            db.execute("update student_accounts set lifetime_points=max(0,points)")
        db.executescript(
            """
            create table if not exists admission_assessments (
              account_id text primary key references student_accounts(id) on delete cascade,
              answers_json text not null default '{}', current_index integer not null default 0,
              status text not null default 'in_progress' check(status in ('in_progress','completed')),
              report_json text, started_at text not null, updated_at text not null, completed_at text
            );
            create table if not exists reward_products (
              id text primary key, title text not null, description text not null default '', image_path text,
              unlock_points integer not null, cost_points integer not null, created_by text not null,
              deleted_at text, created_at text not null, updated_at text not null
            );
            create table if not exists reward_product_classes (
              product_id text not null references reward_products(id) on delete cascade,
              class_id text not null, stock_total integer not null, stock_available integer not null,
              active integer not null default 1, created_at text not null, updated_at text not null,
              primary key(product_id,class_id)
            );
            create table if not exists reward_redemptions (
              id text primary key, product_id text not null references reward_products(id), class_id text not null,
              account_id text not null references student_accounts(id) on delete cascade,
              cost_points integer not null, status text not null check(status in ('pending','approved','rejected','claimed')),
              reject_reason text not null default '', created_at text not null, updated_at text not null,
              approved_at text, claimed_at text
            );
            create table if not exists game_draws (
              id text primary key, account_id text not null references student_accounts(id) on delete cascade,
              draw_date text not null, game_title text not null, game_url text not null, game_category text not null,
              created_at text not null
            );
            create index if not exists admission_status_idx on admission_assessments(status,updated_at);
            create index if not exists reward_classes_idx on reward_product_classes(class_id,active);
            create index if not exists reward_redemptions_class_idx on reward_redemptions(class_id,status,created_at);
            create index if not exists reward_redemptions_account_idx on reward_redemptions(account_id,created_at);
            create index if not exists game_draw_account_date_idx on game_draws(account_id,draw_date);
            """
        )
        # The old communication square was explicitly retired; production startup performs the final purge.
        purge_legacy_community(db)
        db.commit()

    with app.app_context():
        init_schema()

    def assessment_payload(account: Any) -> dict[str, Any]:
        row = get_db().execute("select * from admission_assessments where account_id=?", (account["id"],)).fetchone()
        if not row:
            return {"status": "not_started", "answers": {}, "currentIndex": 0, "questions": QUESTIONS, "options": SCALE_OPTIONS, "report": None}
        answers = json.loads(row["answers_json"] or "{}")
        return {
            "status": row["status"], "answers": answers, "currentIndex": int(row["current_index"] or 0),
            "questions": QUESTIONS if row["status"] != "completed" else [], "options": SCALE_OPTIONS,
            "report": json.loads(row["report_json"]) if row["report_json"] else None,
            "startedAt": row["started_at"], "updatedAt": row["updated_at"], "completedAt": row["completed_at"],
        }

    @app.get("/api/parent/admission-assessment")
    @require_parent
    def parent_admission_assessment():
        return jsonify(assessment_payload(g.parent_student_account))

    @app.put("/api/parent/admission-assessment/progress")
    @require_parent
    def save_admission_progress():
        body = json_body(); db = get_db(); account = g.parent_student_account
        existing = db.execute("select * from admission_assessments where account_id=?", (account["id"],)).fetchone()
        if existing and existing["status"] == "completed":
            return jsonify({"error": "入学测评已经完成，不能重新作答。"}), 409
        raw_answers = body.get("answers") if isinstance(body.get("answers"), dict) else {}
        valid_ids = {item["id"] for item in QUESTIONS}
        answers = {}
        for key, value in raw_answers.items():
            if key in valid_ids:
                try: score = int(value)
                except (TypeError, ValueError): continue
                if 1 <= score <= 5: answers[key] = score
        current_index = max(0, min(79, int(body.get("currentIndex") or 0)))
        now = iso_now()
        db.execute(
            """insert into admission_assessments(account_id,answers_json,current_index,status,started_at,updated_at)
               values(?,?,?,'in_progress',?,?)
               on conflict(account_id) do update set answers_json=excluded.answers_json,current_index=excluded.current_index,updated_at=excluded.updated_at
               where admission_assessments.status='in_progress'""",
            (account["id"], json.dumps(answers, ensure_ascii=False), current_index, now, now),
        )
        db.commit()
        return jsonify({"ok": True, "saved": len(answers), "updatedAt": now})

    @app.post("/api/parent/admission-assessment/submit")
    @require_parent
    def submit_admission_assessment():
        body = json_body(); db = get_db(); account = g.parent_student_account
        existing = db.execute("select * from admission_assessments where account_id=?", (account["id"],)).fetchone()
        if existing and existing["status"] == "completed":
            return jsonify({"error": "入学测评已经完成，不能重复提交。"}), 409
        raw_answers = body.get("answers") if isinstance(body.get("answers"), dict) else {}
        answers: dict[str, int] = {}
        for item in QUESTIONS:
            try: value = int(raw_answers.get(item["id"]))
            except (TypeError, ValueError): value = 0
            if not 1 <= value <= 5:
                return jsonify({"error": f"第 {item['number']} 题还没有作答。"}), 400
            answers[item["id"]] = value
        report = _build_report(answers); now = iso_now()
        db.execute(
            """insert into admission_assessments(account_id,answers_json,current_index,status,report_json,started_at,updated_at,completed_at)
               values(?,?,79,'completed',?,?,?,?)
               on conflict(account_id) do update set answers_json=excluded.answers_json,current_index=79,status='completed',
                 report_json=excluded.report_json,updated_at=excluded.updated_at,completed_at=excluded.completed_at
               where admission_assessments.status='in_progress'""",
            (account["id"], json.dumps(answers, ensure_ascii=False), json.dumps(report, ensure_ascii=False), now, now, now),
        )
        db.commit()
        return jsonify(assessment_payload(account))

    @app.get("/api/admin/admission-assessments")
    @require_admin
    def admin_admission_assessments():
        class_id = request.args.get("class_id", "").strip(); db = get_db()
        rows = db.execute(
            """select a.*,s.student_name,s.student_id from student_accounts s
               left join admission_assessments a on a.account_id=s.id
               where s.deleted_at is null and s.active=1 and (?='' or s.class_ids like ?)
               order by s.student_name collate nocase""", (class_id, f'%"{class_id}"%'),
        ).fetchall()
        items = []
        for row in rows:
            items.append({
                "accountId": row["account_id"], "studentId": row["student_id"], "studentName": row["student_name"],
                "status": row["status"] or "not_started", "currentIndex": int(row["current_index"] or 0) if row["account_id"] else 0,
                "report": json.loads(row["report_json"]) if row["report_json"] else None,
                "startedAt": row["started_at"], "updatedAt": row["updated_at"], "completedAt": row["completed_at"],
            })
        return jsonify({"items": items})

    def product_dict(row: Any) -> dict[str, Any]:
        return {
            "id": row["id"], "title": row["title"], "description": row["description"],
            "imageUrl": f"/uploads/{row['image_path']}" if row["image_path"] else None,
            "unlockPoints": int(row["unlock_points"]), "costPoints": int(row["cost_points"]),
            "classId": row["class_id"], "stockTotal": int(row["stock_total"]),
            "stockAvailable": int(row["stock_available"]), "active": bool(row["active"]),
            "createdAt": row["created_at"], "updatedAt": row["updated_at"],
        }

    def save_reward_image(uploaded: Any, product_id: str) -> str | None:
        if not uploaded or not uploaded.filename:
            return None
        mime = str(uploaded.mimetype or "").lower()
        suffix = Path(secure_filename(uploaded.filename)).suffix.lower()
        if mime not in {"image/jpeg", "image/png", "image/webp"} or suffix not in {".jpg", ".jpeg", ".png", ".webp"}:
            raise ValueError("商品图片仅支持 JPG、PNG 或 WebP。")
        relative = f"rewards/{product_id}{suffix}"
        destination = Path(current_app.config["UPLOAD_ROOT"]) / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        uploaded.save(destination)
        if destination.stat().st_size > 10 * 1024 * 1024:
            destination.unlink(missing_ok=True)
            raise ValueError("商品图片不能超过 10MB。")
        compress_image_file(destination, mime)
        return relative

    @app.get("/api/admin/reward-products")
    @require_admin
    def admin_reward_products():
        class_id = request.args.get("class_id", "").strip(); db = get_db()
        rows = db.execute(
            """select p.*,c.class_id,c.stock_total,c.stock_available,c.active,c.updated_at class_updated_at
               from reward_products p join reward_product_classes c on c.product_id=p.id
               where p.deleted_at is null and (?='' or c.class_id=?) order by p.unlock_points,p.created_at""",
            (class_id, class_id),
        ).fetchall()
        products = []
        for row in rows:
            item = product_dict(row); item["updatedAt"] = row["class_updated_at"]; products.append(item)
        redemptions = [dict(row) for row in db.execute(
            """select r.*,p.title product_title,p.image_path,s.student_name from reward_redemptions r
               join reward_products p on p.id=r.product_id join student_accounts s on s.id=r.account_id
               where (?='' or r.class_id=?) order by r.created_at desc""", (class_id, class_id),
        ).fetchall()]
        for item in redemptions:
            item["image_url"] = f"/uploads/{item['image_path']}" if item.get("image_path") else None
        return jsonify({"products": products, "redemptions": redemptions})

    @app.post("/api/admin/reward-products")
    @require_admin
    def create_reward_product():
        try:
            title = str(request.form.get("title", "")).strip()[:120]
            description = str(request.form.get("description", "")).strip()[:1000]
            unlock_points = int(request.form.get("unlockPoints") or 0)
            cost_points = int(request.form.get("costPoints") or 0)
            stock = int(request.form.get("stock") or 0)
            class_ids = json.loads(request.form.get("classIds") or "[]")
            class_ids = list(dict.fromkeys(str(item).strip() for item in class_ids if str(item).strip()))
        except (TypeError, ValueError, json.JSONDecodeError):
            return jsonify({"error": "商品积分、库存或班级信息格式不正确。"}), 400
        if not title or unlock_points < 0 or cost_points <= 0 or stock <= 0 or not class_ids:
            return jsonify({"error": "请完整填写商品名称、解锁积分、兑换积分、库存和班级。"}), 400
        product_id = str(uuid.uuid4()); now = iso_now()
        try: image_path = save_reward_image(request.files.get("image"), product_id)
        except ValueError as exc: return jsonify({"error": str(exc)}), 400
        if not image_path:
            return jsonify({"error": "请上传一张商品图片。"}), 400
        db = get_db(); created_by = str(g.admin_user.get("id") or "admin")
        db.execute("insert into reward_products values (?,?,?,?,?,?,?,?,?,?)", (product_id,title,description,image_path,unlock_points,cost_points,created_by,None,now,now))
        for class_id in class_ids:
            db.execute("insert into reward_product_classes values (?,?,?,?,1,?,?)", (product_id,class_id,stock,stock,now,now))
        db.commit()
        return jsonify({"ok": True, "id": product_id}), 201

    @app.put("/api/admin/reward-products/<product_id>")
    @require_admin
    def update_reward_product(product_id: str):
        is_form = bool(request.form)
        body = request.form if is_form else json_body()
        db = get_db(); product = db.execute("select * from reward_products where id=? and deleted_at is null", (product_id,)).fetchone()
        if not product: return jsonify({"error": "商品不存在。"}), 404
        class_id = str(body.get("classId") or "").strip()
        try:
            title = str(body.get("title", product["title"])).strip()[:120]
            description = str(body.get("description", product["description"])).strip()[:1000]
            unlock_points = int(body.get("unlockPoints", product["unlock_points"]))
            cost_points = int(body.get("costPoints", product["cost_points"]))
            active = str(body.get("active", "true")).lower() not in {"0", "false", "off"}
            stock_total = int(body.get("stockTotal") or 0)
        except (TypeError, ValueError): return jsonify({"error": "商品信息格式不正确。"}), 400
        if not title or unlock_points < 0 or cost_points <= 0: return jsonify({"error": "商品名称和积分设置无效。"}), 400
        image_path = product["image_path"]
        if is_form and request.files.get("image"):
            try: image_path = save_reward_image(request.files.get("image"), product_id)
            except ValueError as exc: return jsonify({"error": str(exc)}), 400
        now = iso_now()
        db.execute("update reward_products set title=?,description=?,image_path=?,unlock_points=?,cost_points=?,updated_at=? where id=?", (title,description,image_path,unlock_points,cost_points,now,product_id))
        if class_id:
            assignment = db.execute("select * from reward_product_classes where product_id=? and class_id=?", (product_id,class_id)).fetchone()
            if not assignment: return jsonify({"error": "商品未发布到这个班级。"}), 404
            reserved = int(assignment["stock_total"]) - int(assignment["stock_available"])
            if stock_total < reserved: return jsonify({"error": f"已有 {reserved} 件被兑换，库存总数不能低于该数量。"}), 400
            db.execute("update reward_product_classes set stock_total=?,stock_available=?,active=?,updated_at=? where product_id=? and class_id=?", (stock_total,stock_total-reserved,1 if active else 0,now,product_id,class_id))
        db.commit(); return jsonify({"ok": True})

    @app.delete("/api/admin/reward-products/<product_id>")
    @require_admin
    def delete_reward_product(product_id: str):
        db = get_db(); used = db.execute("select 1 from reward_redemptions where product_id=? limit 1", (product_id,)).fetchone(); now = iso_now()
        db.execute("update reward_products set deleted_at=?,updated_at=? where id=?", (now,now,product_id))
        db.execute("update reward_product_classes set active=0,updated_at=? where product_id=?", (now,product_id))
        db.commit()
        return jsonify({"ok": True, "message": "商品已有兑换记录，已安全下架并从列表隐藏。" if used else "商品已删除。"})

    @app.get("/api/student/rewards")
    @require_student
    def student_rewards():
        account = g.student_account; memberships = json.loads(account["class_ids"] or "[]")
        requested = request.args.get("class_id", "").strip(); class_id = requested if requested in memberships else (memberships[0] if memberships else "")
        db = get_db(); fresh = db.execute("select * from student_accounts where id=?", (account["id"],)).fetchone()
        rows = db.execute(
            """select p.*,c.class_id,c.stock_total,c.stock_available,c.active,c.updated_at class_updated_at
               from reward_products p join reward_product_classes c on c.product_id=p.id
               where p.deleted_at is null and c.class_id=? and c.active=1 order by p.unlock_points,p.cost_points""", (class_id,),
        ).fetchall()
        products = []
        for row in rows:
            item = product_dict(row); item["unlocked"] = int(fresh["lifetime_points"] or 0) >= item["unlockPoints"]; products.append(item)
        redemptions = [dict(row) for row in db.execute(
            """select r.*,p.title product_title,p.image_path from reward_redemptions r join reward_products p on p.id=r.product_id
               where r.account_id=? and r.class_id=? order by r.created_at desc""", (account["id"],class_id),
        ).fetchall()]
        for item in redemptions: item["image_url"] = f"/uploads/{item['image_path']}" if item.get("image_path") else None
        return jsonify({"classId": class_id, "points": int(fresh["points"] or 0), "lifetimePoints": int(fresh["lifetime_points"] or 0), "products": products, "redemptions": redemptions})

    @app.post("/api/student/redemptions")
    @require_student
    def create_redemption():
        body = json_body(); product_id = str(body.get("productId") or "").strip(); class_id = str(body.get("classId") or "").strip()
        memberships = json.loads(g.student_account["class_ids"] or "[]")
        if class_id not in memberships: return jsonify({"error": "不能兑换其他班级的商品。"}), 403
        db = get_db()
        try:
            db.execute("begin immediate")
            row = db.execute(
                """select p.*,c.stock_available,c.active from reward_products p join reward_product_classes c on c.product_id=p.id
                   where p.id=? and c.class_id=? and p.deleted_at is null""", (product_id,class_id),
            ).fetchone()
            account = db.execute("select * from student_accounts where id=?", (g.student_account["id"],)).fetchone()
            if not row or not row["active"]: raise ValueError("商品已下架。")
            if int(row["stock_available"]) <= 0: raise ValueError("这件奖品已经兑完啦。")
            if int(account["lifetime_points"] or 0) < int(row["unlock_points"]): raise ValueError("累计积分还未达到解锁条件。")
            if int(account["points"] or 0) < int(row["cost_points"]): raise ValueError("当前积分不足，继续完成挑战吧！")
            redemption_id = str(uuid.uuid4()); now = iso_now(); cost = int(row["cost_points"])
            db.execute("update reward_product_classes set stock_available=stock_available-1,updated_at=? where product_id=? and class_id=?", (now,product_id,class_id))
            db.execute("update student_accounts set points=points-?,updated_at=? where id=?", (cost,now,account["id"]))
            db.execute("insert into reward_redemptions values (?,?,?,?,?,'pending','',?,?,null,null)", (redemption_id,product_id,class_id,account["id"],cost,now,now))
            db.execute("insert into point_events(id,account_id,delta,reason,source_id,created_at,source_kind) values(?,?,?,?,?,?,?)", (str(uuid.uuid4()),account["id"],-cost,f"兑换奖品：{row['title']}",f"redemption:{redemption_id}",now,"redemption"))
            db.commit()
        except ValueError as exc:
            db.rollback(); return jsonify({"error": str(exc)}), 400
        except sqlite3.Error:
            db.rollback(); return jsonify({"error": "兑换请求繁忙，请稍后重试。"}), 409
        return jsonify({"ok": True, "id": redemption_id, "status": "pending"}), 201

    @app.patch("/api/admin/redemptions/<redemption_id>")
    @require_admin
    def review_redemption(redemption_id: str):
        body = json_body(); target = str(body.get("status") or "").strip(); reason = str(body.get("reason") or "").strip()[:500]
        if target not in {"approved","rejected","claimed"}: return jsonify({"error": "兑换状态无效。"}), 400
        db = get_db()
        try:
            db.execute("begin immediate")
            row = db.execute("select r.*,p.title from reward_redemptions r join reward_products p on p.id=r.product_id where r.id=?", (redemption_id,)).fetchone()
            if not row: raise ValueError("兑换记录不存在。")
            current = row["status"]
            if target in {"approved","rejected"} and current != "pending": raise ValueError("这条申请已经审核。")
            if target == "claimed" and current != "approved": raise ValueError("只有待领取奖品才能标记为已领取。")
            now = iso_now()
            if target == "rejected":
                db.execute("update student_accounts set points=points+?,updated_at=? where id=?", (row["cost_points"],now,row["account_id"]))
                db.execute("update reward_product_classes set stock_available=stock_available+1,updated_at=? where product_id=? and class_id=?", (now,row["product_id"],row["class_id"]))
                db.execute("insert into point_events(id,account_id,delta,reason,source_id,created_at,source_kind) values(?,?,?,?,?,?,?)", (str(uuid.uuid4()),row["account_id"],row["cost_points"],f"兑换未通过退还：{row['title']}",f"redemption-refund:{redemption_id}",now,"redemption_refund"))
            approved_at = now if target == "approved" else row["approved_at"]
            claimed_at = now if target == "claimed" else row["claimed_at"]
            db.execute("update reward_redemptions set status=?,reject_reason=?,updated_at=?,approved_at=?,claimed_at=? where id=?", (target,reason,now,approved_at,claimed_at,redemption_id))
            db.commit()
        except ValueError as exc:
            db.rollback(); return jsonify({"error": str(exc)}), 400
        return jsonify({"ok": True, "status": target})

    def game_day() -> str:
        return datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat()

    @app.get("/api/student/game-draw/status")
    @require_student
    def game_draw_status():
        rows = get_db().execute("select * from game_draws where account_id=? and draw_date=? order by created_at", (g.student_account["id"],game_day())).fetchall()
        return jsonify({"remaining": max(0,3-len(rows)), "draws": [dict(row) for row in rows], "resetsAt": "北京时间每天 00:00"})

    @app.post("/api/student/game-draw")
    @require_student
    def game_draw():
        db = get_db(); today = game_day()
        rows = db.execute("select * from game_draws where account_id=? and draw_date=? order by created_at", (g.student_account["id"],today)).fetchall()
        if len(rows) >= 3: return jsonify({"error": "今天的 3 次抽奖机会已经用完，明天再来吧！", "remaining": 0}), 429
        used = {row["game_url"] for row in rows}; choices = [item for item in POPULAR_POKI_GAMES if item[1] not in used] or POPULAR_POKI_GAMES
        title,url,category = secrets.choice(choices); row_id = str(uuid.uuid4()); now = iso_now()
        db.execute("insert into game_draws values (?,?,?,?,?,?,?)", (row_id,g.student_account["id"],today,title,url,category,now)); db.commit()
        return jsonify({"game": {"id": row_id, "title": title, "url": url, "category": category}, "remaining": 2-len(rows)}), 201
